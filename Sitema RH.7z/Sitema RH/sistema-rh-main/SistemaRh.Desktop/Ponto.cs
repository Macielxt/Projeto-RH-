﻿using Microsoft.EntityFrameworkCore;
using SistemaRhBase.Database;
using SistemaRhBase.Models;

namespace SistemaRh.Desktop
{
    public partial class Ponto : Form
    {
        private DatabaseContext context = new();
        public Ponto()
        {
            InitializeComponent();
        }

        private void pontosTable_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void AtualizarApontamentoHoras(List<ApontamentoHora> pontos)
        {
            pontosTable.Rows.Clear();
            foreach (var apontamento in pontos)
            {
                pontosTable.Rows.Add(apontamento.Data, apontamento.HoraEntrada, apontamento.HoraSaida, apontamento.HorasTrabalhadasFormatada);
            }
        }

        private void btnIniciarPonto_Click(object sender, EventArgs e)
        {
            Funcionario funcionario = GetFuncionario();

            if (funcionario.ApontamentoHoras.Any(p => p.HoraSaida.Ticks == 0))
            {
                FecharPonto(funcionario);
                return;
            }
            else
            {
                IniciarPonto(funcionario);
            }
        }

        private void IniciarPonto(Funcionario funcionario)
        {
            ApontamentoHora apontamento = new()
            {
                FuncionarioId = funcionario.Id,
                HoraEntrada = TimeOnly.FromDateTime(DateTime.Now),
                Data = DateOnly.FromDateTime(DateTime.Now)
            };
            context.ApontamentosHoras.Add(apontamento);
            context.SaveChanges();

            pontosTable.Rows.Add(apontamento.Data, apontamento.HoraEntrada, apontamento.HoraSaida, apontamento.HorasTrabalhadasFormatada);
        }

        private void FecharPonto(Funcionario funcionario)
        {
            ApontamentoHora? ponto = funcionario.ApontamentoHoras
                .LastOrDefault(p => p.HoraSaida.Ticks == 0);

            funcionario.ApontamentoHoras.Remove(ponto);
            ponto.HoraSaida = TimeOnly.FromDateTime(DateTime.Now);
            funcionario.ApontamentoHoras.Add(ponto);
            context.ApontamentosHoras.Update(ponto);
            context.SaveChanges();

            AtualizarApontamentoHoras(funcionario.ApontamentoHoras);
        }

        private Funcionario GetFuncionario()
        {
            if (!int.TryParse(Environment.GetEnvironmentVariable("matricula"), out int matricula))
            {
                return null;
            }

            Funcionario? funcionario = context.Funcionarios
                .Where(p => p.Matricula == matricula)
                .Include(p => p.ApontamentoHoras)
                .FirstOrDefault();

            if (funcionario == null)
            {
                MessageBox.Show("Funcionário não encontrado");
                return null;
            }

            lblNome.Text = $"Olá {funcionario.Nome}";

            return funcionario;
        }

        public void AtualizarFuncionarioInfos()
        {
            Funcionario fun = GetFuncionario();
            if (fun != null)
            {

                AtualizarApontamentoHoras(fun.ApontamentoHoras);
            }
        }
    }
}