﻿namespace SistemaRh.Desktop
{
    partial class Ponto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pontosTable = new DataGridView();
            Data = new DataGridViewTextBoxColumn();
            HoraEntrada = new DataGridViewTextBoxColumn();
            HoraSaida = new DataGridViewTextBoxColumn();
            Duracao = new DataGridViewTextBoxColumn();
            lblNome = new Label();
            btnRegistrarPonto = new Button();
            ((System.ComponentModel.ISupportInitialize)pontosTable).BeginInit();
            SuspendLayout();
            // 
            // pontosTable
            // 
            pontosTable.AllowUserToOrderColumns = true;
            pontosTable.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            pontosTable.Columns.AddRange(new DataGridViewColumn[] { Data, HoraEntrada, HoraSaida, Duracao });
            pontosTable.GridColor = SystemColors.ActiveBorder;
            pontosTable.Location = new Point(12, 45);
            pontosTable.Name = "pontosTable";
            pontosTable.RowTemplate.Height = 25;
            pontosTable.Size = new Size(444, 393);
            pontosTable.TabIndex = 3;
            pontosTable.CellClick += pontosTable_CellClick;
            // 
            // Data
            // 
            Data.HeaderText = "Data";
            Data.Name = "Data";
            Data.ReadOnly = true;
            // 
            // HoraEntrada
            // 
            HoraEntrada.HeaderText = "Hora Entrada";
            HoraEntrada.Name = "HoraEntrada";
            HoraEntrada.ReadOnly = true;
            // 
            // HoraSaida
            // 
            HoraSaida.HeaderText = "Hora Saida";
            HoraSaida.Name = "HoraSaida";
            HoraSaida.ReadOnly = true;
            // 
            // Duracao
            // 
            Duracao.HeaderText = "Duração";
            Duracao.Name = "Duracao";
            Duracao.ReadOnly = true;
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblNome.Location = new Point(14, 12);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(0, 21);
            lblNome.TabIndex = 4;
            // 
            // btnRegistrarPonto
            // 
            btnRegistrarPonto.Location = new Point(487, 45);
            btnRegistrarPonto.Name = "btnRegistrarPonto";
            btnRegistrarPonto.Size = new Size(123, 41);
            btnRegistrarPonto.TabIndex = 5;
            btnRegistrarPonto.Text = "Registrar Ponto";
            btnRegistrarPonto.UseVisualStyleBackColor = true;
            btnRegistrarPonto.Click += btnIniciarPonto_Click;
            // 
            // Ponto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkSlateBlue;
            ClientSize = new Size(800, 450);
            Controls.Add(btnRegistrarPonto);
            Controls.Add(lblNome);
            Controls.Add(pontosTable);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Ponto";
            Text = "Ponto";
            ((System.ComponentModel.ISupportInitialize)pontosTable).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DataGridView pontosTable;
        private Label lblNome;
        private Button btnRegistrarPonto;
        private DataGridViewTextBoxColumn Data;
        private DataGridViewTextBoxColumn HoraEntrada;
        private DataGridViewTextBoxColumn HoraSaida;
        private DataGridViewTextBoxColumn Duracao;
    }
}