﻿namespace SistemaRh.Desktop
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            inputMatricula = new TextBox();
            inputSenha = new TextBox();
            label1 = new Label();
            label2 = new Label();
            buttonEntrar = new Button();
            SuspendLayout();
            // 
            // inputMatricula
            // 
            inputMatricula.Location = new Point(231, 119);
            inputMatricula.Name = "inputMatricula";
            inputMatricula.Size = new Size(303, 23);
            inputMatricula.TabIndex = 0;
            // 
            // inputSenha
            // 
            inputSenha.Location = new Point(231, 175);
            inputSenha.Name = "inputSenha";
            inputSenha.PasswordChar = '*';
            inputSenha.Size = new Size(303, 23);
            inputSenha.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(231, 88);
            label1.Name = "label1";
            label1.Size = new Size(94, 28);
            label1.TabIndex = 2;
            label1.Text = "Matricula";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(231, 144);
            label2.Name = "label2";
            label2.Size = new Size(65, 28);
            label2.TabIndex = 3;
            label2.Text = "Senha";
            // 
            // buttonEntrar
            // 
            buttonEntrar.Location = new Point(446, 204);
            buttonEntrar.Name = "buttonEntrar";
            buttonEntrar.Size = new Size(88, 31);
            buttonEntrar.TabIndex = 4;
            buttonEntrar.Text = "Entrar";
            buttonEntrar.UseVisualStyleBackColor = true;
            buttonEntrar.Click += buttonEntrar_Click;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkSlateBlue;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonEntrar);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(inputSenha);
            Controls.Add(inputMatricula);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Login";
            Text = "Login";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox inputMatricula;
        private TextBox inputSenha;
        private Label label1;
        private Label label2;
        private Button buttonEntrar;
    }
}