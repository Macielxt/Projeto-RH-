namespace SistemaRh.Desktop
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
            Ponto ponto = new()
            {
                TopLevel = false
            };
            Login login = new()
            {
                TopLevel = false
            };

            panelPrincipal.Controls.Add(login);

            panelPrincipal.Controls.Add(ponto);
            login.VisibleChanged += (sender, args) =>
            {
                if (!login.Visible)
                {
                    ponto.Show();
                    ponto.AtualizarFuncionarioInfos();
                }
            };

            login.Show();
        }
    }
}