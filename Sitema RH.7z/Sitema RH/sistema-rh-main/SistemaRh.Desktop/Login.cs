﻿using SistemaRhBase.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaRh.Desktop
{
    public partial class Login : Form
    {
        private readonly DatabaseContext context = new();
        public Login()
        {
            InitializeComponent();
        }

        public void btnEntrar_Click(object sender, EventArgs e)
        {

        }

        private void buttonEntrar_Click(object sender, EventArgs e)
        {
            int.TryParse(inputMatricula.Text, out int matricula);

            var funcionario = context.Funcionarios.FirstOrDefault(f => f.Matricula == matricula && f.Senha == inputSenha.Text);
            if (funcionario == null)
            {
                MessageBox.Show("Login Invalido");
                return;
            }

            Environment.SetEnvironmentVariable("matricula", funcionario.Matricula.ToString());


            Hide();
        }
    }
}
