﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace SistemaRhBase.Models
{
    public class Funcionario
    {
        public int Id { get; set; }
        public int Matricula { get; set; }
        public string Nome { get; set; } = default!;
        [DisplayFormat(DataFormatString = "{0:O}", ApplyFormatInEditMode = true)]
        public DateOnly DataAdmissao { get; set; }
        public string Cargo { get; set; } = default!;
        public double ValorHora { get; set; }
        public double SalarioBruto { get; set; }
        public string Telefone { get; set; } = default!;
        public string CPF { get; set; } = default!;
        public string Senha { get; set; } = default!;
        public bool Ativo { get; set; }

        [NotMapped]
        public List<ValorMes> ValorMeses => ApontamentoHoras
            .Select(p => new ValorMes
            {
                Ano = p.Data.Year,
                Mes = p.Data.Month,
                Valor = p.HorasTrabalhadas.TotalHours * ValorHora
            })
            .OrderBy(p => p.Ano)
            .ThenBy(p => p.Mes)
            .ToList();

        [NotMapped]
        public List<ValorMes> ValorMesAtual => ValorMeses
            .Where(p => p.Ano == DateTime.Now.Year && p.Mes == DateTime.Now.Month)
            .ToList();

        [NotMapped]
        public List<ApontamentoHora> ApontamentoHorasMesAtual => ApontamentoHoras
            .Where(p => p.Data.Year == DateTime.Now.Year && p.Data.Month == DateTime.Now.Month)
            .ToList();

        public List<FolhaDePagamento> FolhaDePagamentos { get; set; } = new();

        public List<ApontamentoHora> ApontamentoHoras { get; set; } = new();
    }
}
