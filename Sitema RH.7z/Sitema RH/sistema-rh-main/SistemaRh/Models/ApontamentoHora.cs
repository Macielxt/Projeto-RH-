﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace SistemaRhBase.Models
{
    public class ApontamentoHora
    {
        public int Id { get; set; }
        public DateOnly Data { get; set; }
        public TimeOnly HoraEntrada { get; set; }
        public TimeOnly HoraSaida { get; set; }
        [NotMapped]
        public TimeSpan HorasTrabalhadas => (HoraSaida.Ticks == 0 ? TimeOnly.FromDateTime(DateTime.Now) : HoraSaida) - HoraEntrada;
        public int FuncionarioId { get; set; }

        [ForeignKey("FuncionarioId")]
        public Funcionario Funcionario { get; set; } = default!;
        [NotMapped]
        public string HorasTrabalhadasFormatada => $"{HorasTrabalhadas.Hours}h:{HorasTrabalhadas.Minutes}m:{HorasTrabalhadas.Seconds}s";
    }
}
