﻿namespace SistemaRhBase.Models
{
    public class Administrador
    {
        public int Id { get; set; }
        public string Usuario { get; set; } = default!;
        public string Senha { get; set; } = default!;
    }
}
