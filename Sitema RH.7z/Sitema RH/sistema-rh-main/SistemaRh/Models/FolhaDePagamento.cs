﻿using System;

namespace SistemaRhBase.Models
{
    public class FolhaDePagamento
    {
        public int Id { get; set; }
        public int FuncionarioId { get; set; }
        public int ValeAlimentacao { get; set; }
        public int DescontoInss { get; set; }
        public int DescontoIrrf { get; set; }
        public int DescontoBeneficios { get; set; }
        public double ValorBruto { get; set; }
        public double ValorTotal { get; set; }
        public StatusFolhaDePagamento Status { get; set; }
        public DateOnly Data { get; set; }

        public Funcionario Funcionario { get; set; }

        public void CalcularEAtualizarValorTotal()
        {
            ValorTotal = ValorBruto;

            ValorTotal -= ValorBruto * ValeAlimentacao / 100;
            ValorTotal -= ValorBruto * DescontoInss / 100;
            ValorTotal -= ValorBruto * DescontoBeneficios / 100;
            ValorTotal -= ValorBruto * DescontoIrrf / 100;

        }

    }

    public enum StatusFolhaDePagamento
    {
        Concluido,
        Pendente
    }
}
