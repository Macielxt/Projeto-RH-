﻿namespace SistemaRhBase.Models
{
    public class ValorMes
    {
        public int Mes { get; set; }
        public int Ano { get; set; }
        public double Valor { get; set; }
    }
}
