﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SistemaRhBase.Migrations
{
    /// <inheritdoc />
    public partial class CorrecaoFolhaDePagamento : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "ValeIrrfPorcentagem",
                table: "FolhasDePagamento",
                newName: "ValeAlimentacao");

            migrationBuilder.RenameColumn(
                name: "ValeInssPorcentagem",
                table: "FolhasDePagamento",
                newName: "DescontoIrrf");

            migrationBuilder.RenameColumn(
                name: "ValeAlimentacaoPorcentagem",
                table: "FolhasDePagamento",
                newName: "DescontoInss");

            migrationBuilder.RenameColumn(
                name: "BaneficioPorcentagem",
                table: "FolhasDePagamento",
                newName: "DescontoBeneficios");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "ValeAlimentacao",
                table: "FolhasDePagamento",
                newName: "ValeIrrfPorcentagem");

            migrationBuilder.RenameColumn(
                name: "DescontoIrrf",
                table: "FolhasDePagamento",
                newName: "ValeInssPorcentagem");

            migrationBuilder.RenameColumn(
                name: "DescontoInss",
                table: "FolhasDePagamento",
                newName: "ValeAlimentacaoPorcentagem");

            migrationBuilder.RenameColumn(
                name: "DescontoBeneficios",
                table: "FolhasDePagamento",
                newName: "BaneficioPorcentagem");
        }
    }
}
