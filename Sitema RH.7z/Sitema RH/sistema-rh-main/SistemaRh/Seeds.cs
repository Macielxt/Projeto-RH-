﻿using SistemaRhBase.Database;
using SistemaRhBase.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaRhBase
{
    public class Seeds
    {
        private static readonly DatabaseContext context = new();
        public static void Seed()
        {
            SeedFuncionarios();
            SeedAdministradores();
        }
        public static void SeedAdministradores()
        {
            if (context.Administradores.Any())
            {
                return;
            }

            List<Administrador> administradores = new()
            {
                new Administrador
                {
                    Usuario = "admin",
                    Senha = "admin",
                },
            };
            context.Administradores.AddRange(administradores);
            context.SaveChanges();
        }
        public static void SeedFuncionarios()
        {
            if (context.Funcionarios.Any())
            {
                return;
            }

            List<Funcionario> funcionarios = new()
            {
                new Funcionario
                {
                    Matricula = 651659,
                    Nome = "João",
                    DataAdmissao = new DateOnly(2021, 1, 1),
                    Cargo = "Design",
                    ValorHora = 100,
                    SalarioBruto = 3500,
                    Telefone = "11999999999",
                    CPF = "12345678900",
                    Ativo = true,
                    Senha = "123456",
                    ApontamentoHoras = new()
                    {
                        new ApontamentoHora
                        {
                            Data = new DateOnly(2023, 1, 1),
                            HoraEntrada = new TimeOnly(8, 0, 0),
                            HoraSaida = new TimeOnly(12, 0, 0),
                        },
                        new ApontamentoHora
                        {
                            Data = new DateOnly(2023, 1, 1),
                            HoraEntrada = new TimeOnly(13, 0, 0),
                            HoraSaida = new TimeOnly(17, 0, 0),
                        },
                        new ApontamentoHora
                        {
                            Data = DateOnly.FromDateTime(DateTime.Now),
                            HoraEntrada = TimeOnly.FromDateTime(DateTime.Now),
                            HoraSaida = TimeOnly.FromDateTime(DateTime.Now.AddHours(2.5)),
                        },
                    }
                },
                new Funcionario
                {
                    Matricula = 168181,
                    Nome = "Maria",
                    DataAdmissao = new DateOnly(2021, 1, 1),
                    Cargo = "Gerente",
                    ValorHora = 120,
                    SalarioBruto = 4200,
                    Telefone = "11999999999",
                    CPF = "12345678900",
                    Ativo = true,
                    Senha = "123456"
                },
                new Funcionario
                {
                    Matricula = 798651,
                    Nome = "José",
                    DataAdmissao = new DateOnly(2021, 1, 1),
                    Cargo = "Desenvolvedor",
                    ValorHora = 150,
                    SalarioBruto = 3700,
                    Telefone = "11999999999",
                    CPF = "12345678900",
                    Ativo = true,
                    Senha = "123456"
                },
            };

            context.Funcionarios.AddRange(funcionarios);
            context.SaveChanges();
        }
    }
}
