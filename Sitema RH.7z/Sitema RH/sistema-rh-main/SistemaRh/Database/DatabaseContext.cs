﻿using Microsoft.EntityFrameworkCore;
using SistemaRhBase.Models;

namespace SistemaRhBase.Database
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext() { }
        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseMySql("Server=localhost;Port=3306;Database=sistema_rh;Uid=root;Pwd=admin;", ServerVersion.AutoDetect("Server=localhost;Port=3306;Database=sistema_rh;Uid=root;Pwd=admin;"));
        }

        public DbSet<ApontamentoHora> ApontamentosHoras => Set<ApontamentoHora>();
        public DbSet<Funcionario> Funcionarios => Set<Funcionario>();
        public DbSet<Administrador> Administradores => Set<Administrador>();
        public DbSet<FolhaDePagamento> FolhasDePagamento => Set<FolhaDePagamento>();
    }
}
