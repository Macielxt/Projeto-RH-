﻿using Microsoft.AspNetCore.Mvc;
using SistemaRhBase.Database;
using SistemaRhBase.Models;

namespace SistemaRh.WebApp.Controllers
{
    public class LoginController : Controller
    {
        DatabaseContext context = new();
        public IActionResult Admin()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AdminLogin(Administrador admin)
        {
            if (context.Administradores.Any(p => p.Usuario == admin.Usuario && p.Senha == admin.Senha))
            {
                return RedirectToAction("Admin", "Home");
            }

            TempData["mensage"] = "Usuario ou senha incorretos";

            return RedirectToAction("Admin");
        }

        public IActionResult Funcionario()
        {
            return View();
        }

        [HttpPost]
        public IActionResult FuncionarioLogin(Funcionario funcionario)
        {
            if (context.Funcionarios.Any(p => p.Matricula == funcionario.Matricula && p.Senha == funcionario.Senha))
            {
                HttpContext.Session.SetString("matricula", funcionario.Matricula.ToString());

                return RedirectToAction("Funcionario", "Home");
            }

            TempData["mensage"] = "Matricula ou senha incorretos";

            return RedirectToAction("Index", "Home");
        }
    }
}
