﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SistemaRhBase.Database;
using SistemaRhBase.Models;

namespace SistemaRh.WebApp.Controllers
{
    public class FolhaDePagamentoController : Controller
    {
        private DatabaseContext context = new();
        public IActionResult Buscar()
        {
            return View();
        }

        public IActionResult Home(int matricula)
        {
            Funcionario? funcionario = context.Funcionarios
                .Include(p => p.FolhaDePagamentos)
                .FirstOrDefault(p => p.Matricula == matricula);

            if (funcionario == null)
            {
                TempData["Mensagem"] = "Funcionário não encontrado";
                return RedirectToAction("Buscar");
            }

            return View(funcionario);
        }
        public IActionResult Funcionario()
        {
            int.TryParse(HttpContext.Session.GetString("matricula"), out int matricula);
            Funcionario? funcionario = context.Funcionarios
                .Include(p => p.FolhaDePagamentos)
                .FirstOrDefault(p => p.Matricula == matricula);

            return View(funcionario);
        }

        public IActionResult Novo(int id, int mes, int year)
        {
            mes = mes == 0 ? DateTime.Now.Month : mes;
            year = year == 0 ? DateTime.Now.Year : year;

            var data = new DateOnly(year, mes, 1);

            var folhaDePagamento = new FolhaDePagamento() { FuncionarioId = id, Data = data };

            var funcionario = context.Funcionarios
                .Include(p => p.ApontamentoHoras
                    .Where(p => p.Data.Month == folhaDePagamento.Data.Month && p.Data.Year == folhaDePagamento.Data.Year))
                .FirstOrDefault(p => p.Id == id);

            return View((folhaDePagamento, funcionario));
        }

        [HttpPost]
        public IActionResult Novo([FromForm] FolhaDePagamento folhaDePagamento)
        {
            folhaDePagamento.Id = 0;

            Funcionario funcionario = context.Funcionarios
                .FirstOrDefault(p => p.Id == folhaDePagamento.FuncionarioId);

            folhaDePagamento.ValorBruto = funcionario.SalarioBruto;

            folhaDePagamento.CalcularEAtualizarValorTotal();

            context.FolhasDePagamento.Add(folhaDePagamento);
            context.SaveChanges();
            
            return RedirectToAction("Home", new { matricula = folhaDePagamento.Funcionario.Matricula });
        }
    }
}
