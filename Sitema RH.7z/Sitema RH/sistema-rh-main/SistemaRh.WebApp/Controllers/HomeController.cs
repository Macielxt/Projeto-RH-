﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace SistemaRh.WebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Admin()
        {
            return View();
        }

        public IActionResult Funcionario()
        {
            return View();
        }
    }
}