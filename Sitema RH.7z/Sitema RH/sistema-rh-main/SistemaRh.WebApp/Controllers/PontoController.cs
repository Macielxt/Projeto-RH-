﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SistemaRhBase.Database;
using SistemaRhBase.Models;

namespace SistemaRh.WebApp.Controllers
{
    public class PontoController : Controller
    {
        private readonly DatabaseContext context = new();

        public IActionResult Buscar()
        {
            return View();
        }

        public IActionResult Home()
        {
            int.TryParse(HttpContext.Session.GetString("matricula"), out int matricula);

            Funcionario? funcionario = context
                .Funcionarios
                .Include(p => p.ApontamentoHoras
                    .Where(p => p.Data == DateOnly.FromDateTime(DateTime.Now)))
                .FirstOrDefault(p => p.Matricula == matricula);

            if (funcionario is null)
            {
                TempData["Mensagem"] = "Funcionário não encontrado";
                return RedirectToAction("Buscar", "Ponto");
            }

            return View(funcionario);
        }

        public IActionResult Iniciar()
        {
            int.TryParse(HttpContext.Session.GetString("matricula"), out int matricula);

            var funcionario = context
                .Funcionarios
                .Include(p => p.ApontamentoHoras
                    .Where(p => p.Data == DateOnly.FromDateTime(DateTime.Now)))
                .FirstOrDefault(p => p.Matricula == matricula);

            if (funcionario is null)
            {
                TempData["Mensagem"] = "Funcionário não encontrado";
                return RedirectToAction("Buscar", "Ponto");
            }
            else if (funcionario.ApontamentoHoras.Any(p => p.HoraSaida.Ticks == 0))
            {
                ApontamentoHora apontamentoHora = funcionario.ApontamentoHoras.First(p => p.HoraSaida.Ticks == 0);
                apontamentoHora.HoraSaida = TimeOnly.FromDateTime(DateTime.Now);
                context.ApontamentosHoras.Update(apontamentoHora);
                context.SaveChanges();
                TempData["Mensagem"] = "Ponto fechado com sucesso";
                return RedirectToAction("Home", "Ponto", new { matriculaId = funcionario.Matricula });
            }
            else
            {
                ApontamentoHora apontamentoHora = new()
                {
                    Data = DateOnly.FromDateTime(DateTime.Now),
                    HoraEntrada = TimeOnly.FromDateTime(DateTime.Now),
                    FuncionarioId = funcionario.Id
                };
                context.ApontamentosHoras.Add(apontamentoHora);
                context.SaveChanges();
                TempData["Mensagem"] = "Ponto iniciado com sucesso";
                return RedirectToAction("Home", "Ponto", new { matriculaId = funcionario.Matricula });
            }
        }

        public IActionResult Fechar([FromRoute] int Id)
        {
            ApontamentoHora? apontamentoHora = context
                .ApontamentosHoras
                .Include(p => p.Funcionario)
                .First(p => p.Id == Id);

            apontamentoHora.HoraSaida = TimeOnly.FromDateTime(DateTime.Now);
            context.ApontamentosHoras.Update(apontamentoHora);
            context.SaveChanges();

            TempData["Mensagem"] = "Ponto fechado com sucesso";
            return RedirectToAction("Home", "Ponto", new { matriculaId = apontamentoHora.Funcionario.Matricula });
        }
    }
}
