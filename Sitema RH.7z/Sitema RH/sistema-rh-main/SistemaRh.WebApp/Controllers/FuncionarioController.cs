﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SistemaRhBase.Database;
using SistemaRhBase.Models;

namespace SistemaRh.WebApp.Controllers
{
    public class FuncionarioController : Controller
    {
        private readonly DatabaseContext context = new();
        public IActionResult Home()
        {
            List<Funcionario> funcionarios = context.Funcionarios
                .Include(p => p.ApontamentoHoras)
                .OrderBy(p => p.Nome)
                .ThenBy(p => p.DataAdmissao)
                .ToList();

            return View(funcionarios);
        }

        [HttpGet]
        public IActionResult Novo()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Cadastro([FromForm] Funcionario funcionario)
        {
            context.Funcionarios.Add(funcionario);
            context.SaveChanges();

            return RedirectToAction("Home", "Funcionario");
        }

        public IActionResult Detalhes([FromRoute] int id)
        {
            Funcionario? funcionario = context
                .Funcionarios
                .Include(p => p.ApontamentoHoras)
                .FirstOrDefault(p => p.Id == id);

            if (funcionario is null)
            {
                return NotFound("Não encontrado");
            }

            return View(funcionario);
        }

        public IActionResult Editar([FromRoute] int id)
        {
            Funcionario? funcionario = context.Funcionarios.Find(id);

            if (funcionario is null)
            {
                return NotFound("Não encontrado");
            }

            return View(funcionario);
        }

        [HttpPost]
        public IActionResult Atualizar([FromForm] Funcionario funcionario)
        {
            
            context.Funcionarios.Update(funcionario);
            context.SaveChanges();

            return RedirectToAction("Home", "Funcionario");
        }
    }
}
